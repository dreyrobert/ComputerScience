from enum import Enum


class Complexidade(Enum):
    Facil = 2
    Medio = 3
    Dificil = 4
