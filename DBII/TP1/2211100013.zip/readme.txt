How to compile:
gcc readFile.o Main.c -o main
How to execute
./main <table name> 
